package com.example.mygatodayan;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity<v> extends AppCompatActivity implements View.OnClickListener{

    private TextView playerOneScore, playerTwoScore, playerStatus;
    private Button[] buttons = new Button [9];
    private Button resetGame;

    private int playerOneScoreCount, playerTwoScoreCount, rountConut;
    boolean activePlayer;

    // p1 => 0
    // p2 => 1
    // empate =>2

    int [] gameState = {2,2,2,2,2,2,2,2,2};

    int [][] winningPositions = {
            {0,1,2}, {3,4,5}, {6,7,8}, //filas
            {0,3,6}, {1,4,7}, {2,5,8}, //columnas
            {0,4,8}, {2,4,6} //cruz
    };




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        playerOneScore = (TextView) findViewById(R.id.playerOne);
        playerTwoScore = (TextView) findViewById(R.id.playerTwoScore);
        playerStatus = (TextView) findViewById(R.id.playerStatus);
        
        resetGame = (Button) findViewById(R.id.resetGame);
        
        for(int i=0; i < buttons.length; i++){
            String buttonID = "btn_" + i;
            int resourceID = getResources().getIdentifier(buttonID, defType:"id", getPackageName());
            buttons[i] = (Button) findViewById(resourceID);
            buttons[i].setOnClickListener(this);
        }

        rountConut = 0;
        playerOneScoreCount = 0;
        playerTwoScoreCount = 0;
        activePlayer = true;

    }

    @Override
    public void onClick(View View v) {
        if(!((Button)v).getText().toString().equals("")){
            return;
        }
        String buttonID = v.getResources().getResourceEntryName(v.getId());
        int gameStatePointer = Integer.parseInt(buttonID.substring(buttonID.length()-1, buttonID.length()));

        if(activePlayer){
            ((Button) v).setText("0");
            ((Button) v).setTextColor(Color.parseColor(colorString:"#70FFEA"));
            gameState[gameStatePointer] = 1;
        }
        rountConut++;

        if(checkWinner()){
            if(activePlayer) {
                playerOneScoreCount++;
                updatePlayerScore();
                Toast.makeText(context: this, text: "El jugador 1 gano!", Toast.LENGTH_SHORT).show();
                playAgain();
            }else {
                playerTwoScoreCount++;
                updatePlayerScore();
                Toast.makeText(context: this, text: "El jugador 2 gano!", Toast.LENGTH_SHORT).show();
                playAgain();

            }

            }else if (rountConut == 9){
                 playAgain();
                 Toast.makeText(context: this, text: "Empate!", Toast.LENGTH_SHORT).show();

            }else {
                activePlayer = !activePlayer;
            }
            if(playerOneScoreCount > playerTwoScoreCount){
                playerStatus.setText("Jugador 1 gano!" );
            }else if(playerTwoScoreCount > playerOneScoreCount){
                playerStatus.setText("Jugador 2 gano");
            }else{
                playerStatus.setText("");
            }
        resetGame.setOneClicklistener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playAgain();
                playerOneScoreCount = 0;
                playerTwoScoreCount = 0;
                playerStatus.setText("");
                updatePlayerScore();

            }
        }};




        public boolean checkWinner(){
            boolean winnerResult = false;

            for(int [] winningPosion : winningPositions) {
                if(gameState[winningPosion[0]] == gmeState[winningPosicion[1]] && gameState[winningPosion[1]] == gameState[winningPosion[2]] &&
                        gameState[winningPosion[0]]!=2){
                    winnerResult = true;
                }

            }
            retrun winnerResult;


        }
        public  void updatePlayerScore(){
            playerOneScore.setText(Integer.toString(playerOneScoreCount));
            playerTwoScore.setText(Integer.toString(playerTwoScoreCount));
        }
        public void playerAgain(){
            rountConut = 0;
            activePlayer = true;

            for(int i = 0; i < buttons.length; i++){
                gameState[i] = 2;
                buttons[i].setText("");
            }
        }



    }